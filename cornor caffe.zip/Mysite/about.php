<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    $serverName="localhost";
    $userName="root";
    $password="";
    $databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    // echo "database is Connected";
}
    ?>
<?php  
    include "include/cssdata.html";
?>
    <title>ABOUT</title>
</head>
<body>
<!-- Navbar Start -->
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">CORNER CAFE</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="/Mysite/" class="nav-item nav-link">Home</a>
                    <a href="profile.php"  class="nav-item nav-link">Profile</a>
                    <a href="about.html" class="nav-item nav-link active">About</a>
                    <a href="setting.php" class="nav-item nav-link">Setting</a>
                    <a href="logout.php" class="nav-item nav-link">Sign out</a>
                    <!-- <a href="signin.php" class="nav-item nav-link">Sign in</a> -->
                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->
 

    <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">About Us</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">About Us</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- About Start -->
    <div class="container-fluid py-5">
        <div class="container">
            <div class="section-title">
                <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">About Us</h4>
                <h1 class="display-4">Serving Since 2006</h1>
            </div>
            <div class="row">
                <div class="col-lg-4 py-0 py-lg-5">
                    <h1 class="mb-3">Our Story</h1>
                    <h5 class="mb-3">A Humble Beginning</h5>
                    <p>In the heart of a bustling city, where the aroma of ambition and dreams filled the air, a small coffee shop named 'CORNER CAFE' opened its doors for the first time in 2006. It was more than just a café; it was a sanctuary for coffee lovers, dreamers, and storytellers. Founded by a passionate barista named Emma and her husband Jack, Brew Haven was born from their shared love for coffee and community.</p>
                    <!-- <a href="" class="btn btn-secondary font-weight-bold py-2 px-4 mt-2">Learn More</a> -->
                </div>
                <div class="col-lg-4 py-5 py-lg-0" style="min-height: 500px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute w-100 h-100" src="../img/about.png" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-4 py-0 py-lg-5">
                    <h1 class="mb-3">The Vision</h1>
                    <p>Emma and Jack envisioned a place where people could escape the chaos of everyday life, even if just for a moment. They wanted 'CORNER CAFE' to be a warm, inviting space where every cup of coffee was crafted with love and precision. Their mission was simple: to create a haven where everyone felt at home.</p>
                    <h5 class="mb-3"><i class="fa fa-check text-primary mr-3"></i>Sustainability initiatives and eco-friendly practices</h5>
                    <h5 class="mb-3"><i class="fa fa-check text-primary mr-3"></i>Active community engagement and support</h5>
                    <h5 class="mb-3"><i class="fa fa-check text-primary mr-3"></i>Awards and industry recognition</h5>
                    <!-- <a href="" class="btn btn-primary font-weight-bold py-2 px-4 mt-2">Learn More</a> -->
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->


    <?php
    include "include/footerdata.html";
    ?>
</body>

</html>