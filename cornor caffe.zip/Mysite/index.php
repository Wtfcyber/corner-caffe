<!DOCTYPE html>
<html>
<head>
	<title>CORNER CAFE</title>
</head>
<body>
<?php  

	include "include/cssdata.html";
	include "include/headerdata.html";
	include "include/bannerdata.html";
	include "include/maindata.html";
	include "include/footerdata.html";
?>
</body>
</html>