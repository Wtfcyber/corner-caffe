<?php 
    session_start();
    if(isset($_SESSION['adminId'])==null){
        
        echo "<script>alert('Somthing went to wrong');document.location.href='../admin.php';</script>";
    }

?>
<html>
<head>
	<title>USERDATA</title>
	<style>
    	
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f0f2f5;
            margin: 20px;
            border-radius: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.7);
            border-radius: 2px;
            margin-bottom: 170px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background-color: #6F4E37;
            color: #ffffff;
            font-weight: 600;
        }
        /*tr:hover {
            background-color: #f1f1f1;
        }*/
        img{
        	height: 30px;      	
        }
        .center{
        	text-align: center;
        }
       
    </style>
</head>
<body>
	<?php
    $serverName="localhost";
    $userName="root";
    $password="";
    $databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    // echo "database is Connected";
 }
?>
<?php  

    include "../user/include/cssdata.html";
    // include "../user/include/headerdata.html";
?>
<div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">Corner Cafe</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                <a href="userdata.php" class="nav-item nav-link active">User</a> 
                <a href="orderdetails.php" class="nav-item nav-link">Orders</a>
                <div>
                    <a href="product.php"class="nav-item nav-link">Products</a>
                </div>     
                     <div>
                <a href="signout.php" class="nav-item nav-link">Sign out</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>
<div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">USER</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">USER</p>
            </div>
        </div>
    </div>
    
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <!-- <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Contact Us</h4> -->
                <h1 class="display-4">USERDATA</h1>
            </div>
   

<?php

 $sql="select * from userdata";
    $result=$conn->query($sql);

 while($row=$result->fetch_assoc()){
    $name=$row["name"];
    $address=$row["address"];
    $phone=$row["phone"];
    $email=$row["email"];
    $Password=$row["password"];
        }

?>
<?php

				$sql="select * from userdata";
				$result=$conn->query($sql);
				$cnt=$result->num_rows;
				if($cnt==0){
					echo "<script>alert('No Record Founds');</script>";
				}
				else
				{

?>
	 <table cellpadding="5" cellspacing="5" border="1">
		<tr>
			<th>Id</th>
			<th>Name</th>
			<th>Phone</th>
			<th>Email</th>
			<th>Address</th>
			<th class="center">Delete</th>
			<!-- <th>Password</th> -->
		</tr>
	<?php
	 while ($row=$result->fetch_assoc()){
	?>
	<tr>
		<td><?php echo $row["uid"];?></td>
		<td><?php echo $row["name"];?></td>
		<td><?php echo $row["phone"];?></td>
		<td><?php echo $row["email"];?></td>
		<td><?php echo $row["address"];?></td>
		<td class="center"><a href="userdata.php?uid=<?php echo $row["uid"];?>">
			<img src="delete1.png"></a></td>
		
	</tr>
		<?php
					}
				}
		?>
	</table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
if(isset($_GET["uid"])!=null){
	$uid=$_GET["uid"];
	$sql="delete from userdata where uid='$uid'";
	if($conn->query($sql)==true){
		echo "<script>alert('User Deleted sucessfully');document.location.href='userdata.php';</script>";
	}
	else
	{
		echo "<script>alert('User not Deleted sucessfully');document.location.href='userdata.php';</script>";
	}

}
?>


<?php
      include "../user/include/footerdata.html";
?>
</body>
</html>