<?php
session_start();
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "mysite";

$conn = new mysqli($serverName, $userName, $password, $databaseName);
if ($conn->connect_error) {
    echo "Database is not connected";
}
?>
<?php
$uid = isset($_GET['uid']) ? $_GET['uid'] : '';
$sql_orders = "select productname, price, quantity, total, image from userorder where uid = $uid";

$resultorders = $conn->query($sql_orders);
$SubTotal = 0;

if ($resultorders->num_rows > 0) {
    while ($row = $resultorders->fetch_assoc()) {
        $SubTotal += $row['total'];
    }
    $GST = $SubTotal * 0.18;
    $SGST = $SubTotal * 0.09;
    $totalWithTax = $SubTotal + $GST + $SGST;
}
?>
<?php include "../user/include/cssdata.html"; ?>
<html>
<title>ORDER DETAILS</title>
<head>
    <style>
        .container {
            padding: 20px;
            margin: 20px auto;
            border-radius: 8px;
            max-width: 1100px;
        }
        tr {
            text-align: center;
        }
        h1 {
            text-align: center;
            font-size: 24px;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
            margin-bottom: 35px;
        }
        table, th, td {
            border: 1px solid #f1f1f1;
        }
        th {
            padding: 15px;
            text-align: center;
        }
        td {
            padding: 15px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        img {
            border-radius: 50%;
            max-width: 100px;
            height: auto;
        }
        .total {
            text-align: left;
            font-weight: bold;
        }
        .totalx {
            text-align: right;
            font-weight: bold;
        }
        #c {
            text-transform: uppercase;
        }gt
    </style>
</head>
<body>
       <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">Corner Cafe</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="userdata.php" class="nav-item nav-link">User</a>
                    <a href="orderdetails.php" class="nav-item nav-link active">Orders</a>
                    <a href="product.php" class="nav-item nav-link">Products</a>
                    <a href="signout.php" class="nav-item nav-link">Sign out</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">ORDER</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">ORDER</p>
            </div>
        </div>
    </div>
    <?php
              $sql="select * from userdata where uid='$uid'";
              $result=$conn->query($sql);
                while($row=$result->fetch_assoc()){
                    $name=$row["name"];
                    $address=$row["address"];
                    $phone=$row["phone"];
                }
        ?>
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <h1 class="display-4" id="c"><?php echo $name ?>'S ORDER</h1>
            </div>
            
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Image</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>                    
                </tr>
            </thead>

            <tbody>
                <?php
                $resultorders->data_seek(0);
                while ($row = $resultorders->fetch_assoc()){ ?>
                    <tr>
                        <td><?php echo $name;?></td> 
                        <td><?php echo $address;?></td>
                        <td><?php echo $phone;?></td>                      
                        <td><img src="../admin/<?php echo $row['image']; ?>" alt="<?php echo $row['productname']; ?>"></td>
                        <td><?php echo $row['productname']; ?></td>
                        <td>RS <?php echo $row['price']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td>RS <?php echo $row['total']; ?></td>                        
                    </tr>
                <?php } ?>
            </tbody>

            <tfoot>
                <tr>
                    <td colspan="7" class="totalx">Sub Total</td>
                    <td class="total">RS <?php echo $SubTotal; ?></td>
                </tr>
                <tr>
                    <td colspan="7" class="totalx">GST 18%</td>
                    <td class="total">RS <?php echo $GST; ?></td>
                </tr>
                <tr>
                    <td colspan="7" class="totalx">SGST 9%</td>
                    <td class="total">RS <?php echo $SGST; ?></td>
                </tr>
                <tr>
                    <td colspan="7" class="totalx" id="t">Net Total (incl all tax)</td>
                    <td class="total" id="t">RS <?php echo $totalWithTax; ?></td>
                </tr>
            </tfoot>
        </table>                      
        </div>
    </div>
    <?php include "../user/include/footerdata.html"; ?>
</body>
</html>