<!DOCTYPE html>
<html>
<head>
    <title>Update Product</title>
<?php
    $serverName = "localhost";
    $userName = "root";
    $password = "";
    $databaseName = "mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);

if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    // echo "database is Connected";
}
?>

    <?php include "../user/include/cssdata.html"; ?>

    <style>
        .body {
            margin-top: 50px;
            margin-bottom: 200px;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .signup-form {
            margin-top: 0px;
            background-color: #ffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
            height: 700px;
            width: 550px;
        }
        .h2 {
            margin-bottom: 20px;
            text-align: center;
            margin-top: 5px;
        }
        .txt {
            width: 95%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .button {
            width: 95%;
            padding: 10px;
            background-color: #6F4E37;
            border: none;
            border-radius: 3px;
            color: #fff;
            font-size: 16px;
            margin-top: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .button:hover {
            background-color: #A67B5B;
            border-radius: 12px;
        }
        .p {
            margin-bottom: 5px;
            margin-top: 5px;
            font-size: 17px;
            margin-left: 5px;
        }
        .sign-up {
            display: flex;
            justify-content: center;
            align-items: center;
            text-decoration: none;
            margin-top: 5px;
        }
        .size {
            height: 120px;
            border-radius: 50%;
        }
        .center {
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>
<!-- Navbar Start -->
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">CORNER CAFE</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="userdata.php" class="nav-item nav-link">User</a>
                    <a href="product.php" class="nav-item nav-link active">Product</a>
                    <a href="logout.php" class="nav-item nav-link">Sign out</a>
                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">PRODUCTS</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">PRODUCTS</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <h1 class="display-4">UPDATE</h1>
            </div>

            <?php
                if (isset($_GET['id'])) {
                    $id = $_GET['id'];
                    $sql = "select * from productdetails where id=$id";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
            ?>

            <div class="body">
                <form class="signup-form" method="post" enctype="multipart/form-data">
                    <div class="center">
                        <img class="size" src="<?php echo $row['image']; ?>">
                    </div>
                    <input class="txt" type="hidden" name="id" value="<?php echo $id; ?>">
                    <p>
                        Name: <input class="txt" type="text" name="name" value="<?php echo $row['name']; ?>">
                    </p>
                    <p>
                        Description: <input class="txt" type="text" name="description" value="<?php echo $row['description']; ?>">
                    </p>
                    <p>
                    Price: 
                    <input class="txt" type="number" name="price" value="<?php echo $row['price']; ?>">
                    </p>
                    <p>
                        Image: <input class="txt" type="file" name="fileToUpload">
                    </p>
                    <button class="button" type="submit" name="update">Update</button>
                </form>
            </div>

            <?php
                    } else {
                        echo "<p class='alert'>Product not found.</p>";
                    }
                }
                if (isset($_POST['update'])) {
                    $id = $_POST['id'];
                    $name = $_POST['name'];
                    $description = $_POST['description'];
                    $price = $_POST['price'];

                    if ($_FILES['fileToUpload']['name']) {
                        $target_path = "productimage/";
                        $target_file = $target_path . basename($_FILES["fileToUpload"]["name"]);
                        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                            $image = $target_file;
                        } else {
                            echo "<script>alert('Image upload failed');</script>";
                            $image = $row["image"];
                        }
                    } else {
                        $image = $row["image"];
                    }

                    $sql = "update productdetails set name='$name', description='$description', price='$price', image='$image' where id=$id";

                    if ($conn->query($sql) === TRUE) {
                        echo "<script>alert('Product updated successfully');document.location.href='product.php';</script>";
                    } else {
                        echo "<script>alert('Product not update failed');document.location.href='update.php?id=$id';</script>";
                    }
                }
            ?>

        </div>o
    </div>

    <?php include "../include/footerdata.html"; ?>
</body>
</html>
