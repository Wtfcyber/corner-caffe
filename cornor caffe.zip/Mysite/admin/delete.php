<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    // echo "database is Connected";
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "delete from productdetails where id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Product deleted successfully');document.location.href='product.php';</script>";
    } else {
        echo "<script>alert('Product deletion failed');document.location.href='product.php';</script>";
    }
}

?>
