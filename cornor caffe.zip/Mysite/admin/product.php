<html>
<head>
	<title>PRODUCT</title>
    <style>  
       .body{
            margin-top: 50px;
            margin-bottom: 200px;
            font-family:Arial,sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .signup-form {
            margin-top: 0px;
            background-color: #ffff;
            padding: 20px;
            border-radius:10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
            height: 550px;
            width: 450px;
           
        }
        .h2 {
            margin-bottom: 20px;
            text-align: center;
            margin-top: 5px;
        }
        .txt{
            width: 95%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .button {
            width: 95%;
            padding: 10px;
            background-color: #6F4E37;
/*            background-color: black;*/
            border: none;
            border-radius: 3px;
            color: #fff;
            font-size: 16px;
            margin-top: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .button:hover {
            background-color:#A67B5B;
/*            background-color:#252525;*/
            border-radius: 12px;
        }
        .p{
            margin-bottom: 5px;
            margin-top: 5px;
            font-size: 17px;
            margin-left: 5px;
        }
        .sign-up{
            display: flex;
            justify-content: center;
            align-items: center;
            text-decoration: none;
            margin-top: 5px;
        }
        .image{
            height: 111px;
            display: flex;
            justify-content: center;
            align-content: center;
        }
         .product-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin-top: 30px;
        }
        .product {
/*            border: 1px solid #ccc;*/
            padding: 10px;
            margin-bottom: 50px;
            border-radius: 5px;
            width: 45%;
            box-sizing: border-box;
            display: flex;
            align-items: center;
        }
        .product img {
            max-width: 100px;
            margin-right: 10px;
            border-radius: 50%;
        }
        .product-details {
            display: flex;
            flex-direction: column;
        }
        .product-price {
            background-color: #6F4E37;
            color: white;
            padding: 5px;
            border-radius: 50%;
            display: inline-block;
            text-align: center;
            font-size: 16px;
            margin-right: 10px;
        }
        .product h3 {
            margin: 0;
        }
    </style>
</head>
 <?php
    $serverName="localhost";
    $userName="root";
    $password="";
    $databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    // echo "database is Connected";
}
$sql="select * from productdetails where id=?";
    $result=$conn->query($sql);

 if($result){
    while($row=$result->fetch_assoc()){
    $id=$row["id"];
    $name=$row["name"];
    $description=$row["description"];
    $price=$row["price"];
    $image=$row["image"];
        }
  }
?>
<?php
    include "../user/include/cssdata.html";
?>
<body>
	<!-- Navbar Start -->
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">CORNER CAFE</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="userdata.php" class="nav-item nav-link">User</a>
                    <a href="orderdetails.php" class="nav-item nav-link">Orders</a>
                    <a href="product.php" class="nav-item nav-link active">Product</a>
                    <a href="logout.php" class="nav-item nav-link">Sign out</a>
                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->
<div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">PRODUCTS</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">PRODUCTS</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->
<div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <h1 class="display-4">UPLOAD</h1>
            </div>
    <div class="body">
        <form class="signup-form" method="post" enctype="multipart/form-data">

        <p class="p">Name</p>
        <input class="txt" type="text" name="name">

        <p class="p">Description</p>
        <input class="txt" id="height" type="description" name="description">

        <p class="p">Price</p>
        <input class="txt" type="number" name="price">

        <p class="p">Image</p>
        <input type="file" name="fileToUpload"/ name="image">  

        <button class="button" type="submit" name="submit" value="Save">Submit</button>
                </form>
</div>
    <?php

            if(isset($_POST["submit"])!=null){
            $action=$_POST["submit"];
            if ($action=="Save"){
                $name=$_POST["name"];
                $description=$_POST["description"];
                $price=$_POST["price"];
                $image=$_POST["fileToUpload"];
            if ($_FILES['fileToUpload']['name']){
                $target_path = "productimage/";
                $target_file = $target_path.basename($_FILES["fileToUpload"]["name"]);
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)){
                $image = $target_file;
             }
             else {
            echo "<script>alert('Image upload failed');</script>";
        }
    }

                $sql="insert into productdetails(name,description,price,image)values('$name','$description','$price','$image')";
                if($conn->query($sql)==true){
                        echo "<script>alert('Product addded sucessfully');document.location.href='product.php';</script>";
                        }
            else
                    {
                    echo "<script>alert('Product not addded sucessfully');document.location.href='product.php';</script>";
                }
            }
        } 
    ?>  
<?php
  $sql = "select * from productdetails";
            $result = $conn->query($sql);
            echo '<div class="product-container">';
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="product">';
                    echo '<div class="product-price">' . $row["price"] . '</div>';
                    echo '<img src="' . $row["image"] . '" alt="' . $row["name"] . '">';
                    echo '<div class="product-details">';
                    echo '<h3>' . $row["name"] . '</h3>';
                    echo '<p>' . $row["description"] .'</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '<br>';
                    echo '<a href="delete.php?id='.$row["id"].'">Delete</a>';
                    echo '<a href="update.php?id='.$row["id"].'">Update</a>';
                }
            }
             else {
                echo '<p>No products found</p>';
            }
            echo '</div>';
?>
					</div>
                </div>
            </div>
        </div>
    </div>

    <?php
    include "../include/footerdata.html";
	?>

</body>
</html>