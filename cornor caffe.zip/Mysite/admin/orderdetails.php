<?php
session_start();
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "mysite";

$conn = new mysqli($serverName, $userName, $password, $databaseName);
if ($conn->connect_error) {
    echo "Database is not connected";
}

$sqlOrder = "select uid, orderdate from userorder";
$resultOrder = $conn->query($sqlOrder);

?>
<?php include "../user/include/cssdata.html"; ?>
<html>
 <title>ORDER DETAILS</title>   
<head>
    <style>
        .container {
            padding: 20px;
            margin: 20px auto;
            border-radius: 8px;
            max-width: 1000px;
        }
        tr {
            text-align: center;
        }
        h1 {
            text-align: center;
            font-size: 24px;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            margin-bottom: 30px;
        }
        table, th, td {
            border: 1px solid #f1f1f1;
        }
        th {
            padding: 15px;
            text-align: center;
        }
        td {
            padding: 15px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        img {
            max-width: 50px;
            height: auto;
        }
    </style>
</head>
<body>
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">Corner Cafe</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="userdata.php" class="nav-item nav-link">User</a>
                    <a href="orderdetails.php" class="nav-item nav-link active">Orders</a>
                    <a href="product.php" class="nav-item nav-link">Products</a>
                    <a href="signout.php" class="nav-item nav-link">Sign out</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">ORDER</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">ORDER</p>
            </div>
        </div>
    </div>
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <h1 class="display-4">ORDER DETAILS</h1>
            </div>
            <table border="1" cellpadding="10" cellspacing="0">
                <tr>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Order Date</th>
                    <th>Order Info</th>
                </tr>
            <?php
                if ($resultOrder->num_rows > 0) {
                    while ($orderRow = $resultOrder->fetch_assoc()){
                        $uid = $orderRow['uid'];
                        $orderDate = $orderRow['orderdate'];

                        $sqlUser = "select name, address from userdata where uid = $uid";
                        $resultUser = $conn->query($sqlUser);
                        $userRow = $resultUser->fetch_assoc();
            ?>
                <tr>
                    <td><?php echo $userRow['name']; ?></td>
                    <td><?php echo $userRow['address']; ?></td>
                    <td><?php echo $orderDate; ?></td>
                    <td><a href="userorder.php?uid=<?php echo $uid; ?>"><img src="infoo.jpg"></a></td>
                </tr>
            <?php
                    } 
                }
            ?>               
            </table>

        </div>
    </div>
    <?php include "../user/include/footerdata.html"; ?>
</body> 
</html>
