<?php
session_start();
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "mysite";

$conn = new mysqli($serverName, $userName, $password, $databaseName);
if ($conn->connect_error) {
    echo "Database is not connected";
}

$sql_orders = "SELECT o.order_id, o.uid, u.name, oa.status 
               FROM userorder o 
               JOIN userdata u ON o.uid = u.uid
               JOIN order_activity oa ON o.order_id = oa.order_id";

$result_orders = $conn->query($sql_orders);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];

    $update_status = "UPDATE order_activity SET status = '$new_status' WHERE order_id = $order_id";
    if ($conn->query($update_status) === TRUE) {
        echo "Order status updated successfully.";
    } else {
        echo "Error updating status: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Order Control</title>
</head>
<body>

<h1>Admin Order Activity Control</h1>

<table>
    <thead>
        <tr>
            <th>Order ID</th>
            <th>User Name</th>
            <th>Current Status</th>
            <th>Update Status</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result_orders->num_rows > 0): ?>
            <?php while ($row = $result_orders->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['order_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td>
                        <form method="POST" action="">
                            <input type="hidden" name="order_id" value="<?php echo $row['order_id']; ?>">
                            <select name="status">
                                <option value="Placed" <?php if ($row['status'] == 'Placed') echo 'selected'; ?>>Placed</option>
                                <option value="Dispatched" <?php if ($row['status'] == 'Dispatched') echo 'selected'; ?>>Dispatched</option>
                                <option value="Delivered" <?php if ($row['status'] == 'Delivered') echo 'selected'; ?>>Delivered</option>
                            </select>
                            <button type="submit">Update</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="4">No orders found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>
