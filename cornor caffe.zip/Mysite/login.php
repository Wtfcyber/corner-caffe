<!DOCTYPE html>
<?php 
session_start();
 ?>
<html>
<head>
    <title>Sign In Form</title>
  
    <?php
    $serverName="localhost";
    $userName="root";
    $password="";
    $databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    //echo "database is Connected";
}
    ?>
    <style>
        body{
            font-family: Arial, sans-serif;
            background-color:#A67B5B;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .signup-form {
            background-color: #ffff;
            padding: 20px;
            border-radius:10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            height: 400px;
            width: 250px;
        }
        .h2 {
            margin-bottom: 20px;
            text-align: center;
            margin-top: 5px;
        }
        .txt{
            width: 90%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .button {

            width: 100%;
            padding: 10px;
            background-color: black;
            border: none;
            border-radius: 3px;
            color: #fff;
            font-size: 16px;
            margin-top: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .button:hover {
            background-color:#252525;
            border-radius: 12px;
        }
        h5{
            margin: 5px;
        }
        .sign-up{
            display: flex;
            justify-content: center;
            align-items: center;
            text-decoration: none;
            margin-top: 5px;
        }
    
    </style>
</head>
<body>
    
    <form class="signup-form" method="post">
        <h2 class="h2">Sign In</h2>

        <h5>Email</h5>
        <input class="txt" type="text" name="email">

        <h5>Password</h5>
        <input class="txt" type="password" name="password">

        <button class="button" type="submit" name="submit" value="Login">Sign In</button>
        <a href="sign.php"class="sign-up">Sign Up</a>
    </form>
    <?php
            if(isset($_POST['submit'])){
                $action= $_POST['submit'];
            if($action=="Login"){
                $uname=$_POST['email'];
                $pass=$_POST['password'];
        $sql="select * from userdata where email = '$uname' and password ='$pass'";
        $result=$conn->query($sql);
        $cnt=$result->num_rows;          
        if ($cnt>0){
                while($row=$result->fetch_assoc()){
                    $uid=$row["uid"];
                }
                $_SESSION["uid"]=$uid;
            echo "<script>alert('Login Sucessfully');document.location.href='index.php'</script>";
         } else {
              echo "<script>alert('Invalid Username and password');document.location.href='login.php'</script>";             
            }
        }
    }
?>

</body>
</html>