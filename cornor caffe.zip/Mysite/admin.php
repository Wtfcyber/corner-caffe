<!DOCTYPE html>
<?php 
session_start();
 ?>
<html>
<head>
    <title>CORNER CAFE</title>
</head>
<style type="text/css">
    form {
            background-color: #ffff;
            padding: 20px;
            border-radius:10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
            height: 450px;
            width: 400px;
            margin-left: 357px;
            margin-bottom: 150px;
    .txt{
            width: 90%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-left: 10px;
        }
        .button {
            margin-left: 10px;
            width: 90%;
            padding: 10px;
            background-color: #6F4E37;
            border: none;
            border-radius: 3px;
            color: #fff;
            font-size: 16px;
            margin-top: 20px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .button:hover{
            background-color:#A67B5B;
            border-radius: 12px;
        }
        .sign-up{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 5px;
        }
        .p{
            margin-bottom: 5px;
            margin-top: 5px;
            font-size: 17px;
            margin-left: 12px;
        }

</style>
<body>
    <?php
    $serverName="localhost";
    $userName="root";
    $password="";
    $databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    // echo "database is Connected";
}
    ?>
<?php  

    include "include/cssdata.html";
    include "include/headerdata.html";
?>
<div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">ADMIN SIGN IN</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">ADMIN SIGN IN</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

    <!-- Contact Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <!-- <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Contact Us</h4> -->
                <h1 class="display-4">ADMIN SIGN IN</h1>
            </div>
        <form class="signup-form" method="post">
        <p class="p">Email</p>
        <input class="txt" type="text" name="email">

        <p class="p">Password</p>
        <input class="txt" type="password" name="password">
<br>
        <button class="button" type="submit" name="submit" value="Login">Sign In</button>
        <br>

        
    </form>
    <?php
             if(isset($_POST['submit'])){
                $action= $_POST['submit'];
            if($action=="Login"){
                $uname=$_POST['email'];
                $pass=$_POST['password'];
        $sql="select * from admin where uname = '$uname' and password ='$pass'";
        $result=$conn->query($sql);
        echo "===>".$sql;
        $cnt=$result->num_rows;          
        if ($cnt>0){
                    
                 $_SESSION["adminId"]="admin";
            echo "<script>alert('Login Sucessfully');document.location.href='admin/userdata.php'</script>";
         } else {
             echo "<script>alert('Invalid Username and password');document.location.href='admin.php';</script>";                
            }
        }
    }
?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->


<?php
    include "include/footerdata.html";
?>
</body>
</html>