<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
    <script type="text/javascript">
    function validation()
        {
            var name=document.data.name.value;
            if(name.length==0)
            {
                alert('Pls Enter Name');
                document.data.name.focus();
                return false;
            }
            if(name.length <2)
            {
                alert('Pls Enter valid Name');
                document.data.name.focus();
                return false;
            }

            var address=document.data.address.value;
            if(address.length==0){
                alert('Pls Enter address');
                address=document.data.address.value;
                return false;
            }
            var address=document.data.address.value;
            if(address.length==0){
                alert('Pls Enter address');
                address=document.data.address.value;
                return false;
            }
            if(address.length <5)
            {
                alert('Pls Enter valid  address');
                document.data.name.focus();
                return false;
            }

            var phone=document.data.phone.value;
            if(phone.length==0)
            {
                alert('Pls Enter Contact Number');
                document.data.phone.focus();
                return false;
            }
            var phoneexp = /^\d{10}$/;
            if(!phone.match(phoneexp))
            {
                alert('Pls Enter Valid Contact Number');
                document.data.phone.focus();
                return false;
            }

            var email=document.data.email.value;
            if(email.length==0)
            {
                alert('Pls Enter Email');
                document.data.email.focus();
                return false;
            }
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            if(!email.match(mailformat))
            {
                alert("Enter Valid email address!");
                document.data.email.focus();
                return false;
            } 

            var password=document.data.password.value;
            if(password.length==0)
            {
                alert('Pls Enter Password');
                document.data.password.focus();
                return false;
            }
            if(password.length <8 || password.length>20)
            {
                alert('Password min length is 8 and max is 20');
                document.data.password.focus();
                return false;
            }
            var lowerCaseLetters = /[a-z]/g;
            if(!password.match(lowerCaseLetters))
            {
                alert('Password Contain Atleast one Lower Case');
                document.data.password.focus();
                return false;
            }
            var upperCaseLetters = /[A-Z]/g;
            if(!password.match(upperCaseLetters))
            {
                alert('Password Contain Atleast one Upper Case');
                document.data.password.focus();
                return false;
            }
            var number = /[0-9]/g;
            if(!password.match(number))
            {
                alert('Password Contain Atleast one Digit');
                document.data.password.focus();
                return false;
            }
            var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
            if(!password.match(format))
            {
                alert('Password Contain Atleast one Special Character');
                document.data.password.focus();
                return false;
            }
            
            return true;
        }
    </script>
	<style type="text/css">
		form {
			background-color: #ffff;
            padding: 20px;
            border-radius:10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
            height: 600px;
            width: 400px;
            margin-left: 355px;     
    .txt{
            width: 90%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-left: 15px;
        }
        .button {
        	margin-left: 15px;
            width: 90%;
            padding: 10px;
            background-color: #6F4E37;
            border: none;
            border-radius: 3px;
            color: #fff;
            font-size: 16px;
            margin-top: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .button:hover{
            background-color:#A67B5B;
            border-radius: 12px;
        }
        .sign-up{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 5px;
        }
        .p{
        	margin-bottom: 5px;
       		margin-top: 5px;
        	font-size: 17px;
        	margin-left: 15px;
        }

	</style>
    <?php
    $serverName="localhost";
    $userName="root";
    $password="";
    $databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    // echo "database is Connected";
}
    ?>
<?php
	include "include/cssdata.html";
    // include "include/headerdata.html";
?>
</head>
<body>
    <!-- Navbar Start -->
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">CORNER CAFE</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="/Mysite/" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link ">About</a>
                    <a href="signin.php" class="nav-item nav-link active">Sign in</a>
                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->
    
   <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">sign Up</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">Sign Up</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Contact Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <!-- <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Contact Us</h4> -->
                <h1 class="display-4">SIGN UP HERE</h1>
            </div>

        <form class="signup-form" method="POST" name="data"onsubmit="return validation()">

        <p class="p">Name</p>
        <input class="txt" type="text" name="name">

        <p class="p">Address</p>
        <input class="txt" type="text" name="address">

        <p class="p">Phone</p>
        <input class="txt" type="number" name="phone">

        <p class="p">Email</p>
        <input class="txt" type="text" name="email">

        <p class="p">Password</p>
        <input class="txt" type="password" name="password">

        <button class="button" type="submit" name="submit" value="Save">Sign Up</button>

        <a href="signin.php"class="sign-up">Sign In</a>
   		</form>


  					</div>
                </div>
            </div>
        </div>
    </div>
    <?php
    if(isset($_POST["submit"])!=null)
        {
            $action=$_POST["submit"];
            if ($action=="Save"){
                $name=$_POST["name"];
                $address=$_POST["address"];
                $phone=$_POST["phone"];
                $email=$_POST["email"];
                $pass=$_POST["password"];
                $sql="insert into userdata(name,address,phone,email,password)values('$name','$address',
            '$phone','$email','$pass')";
                                    
            if($conn->query($sql)==true){
                        echo "<script>alert('User addded sucessfully');document.location.href='signin.php';</script>";
                        }
            else
                    {
                    echo "<script>alert('User not addded sucessfully');document.location.href='signup.php';</script>";
                }
            }
        } 
    ?>
<?php
	include "include/footerdata.html";
?>
</body>
</html>