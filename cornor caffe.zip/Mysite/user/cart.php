<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MY CART</title>
    <style>
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 100px;
        }
        table, th, td {
            border: 1px solid #f1f1f1;
        }
        th, td {
            padding: 15px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .remove-link {
            color: #9C7248;
            text-decoration: none;
        }
        .remove-link:hover {
            color: #9C7248;
            text-decoration: underline;
        }
        img {
            height: 100px;
            border-radius: 50%;
        }
        .center {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .size {
            height: 40px;
        }
        .div {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .button {
            background-color:#6F4E37; 
            color: white;
            padding: 10px 20px; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
            font-size: 16px;
        }
        button:hover {
            border-radius:8px;
            background-color:#A67B5B;
        }
        .a {
            color: white;
        }
    </style>
</head>
<?php
    include "include/cssdata.html";
?>
<?php
session_start();

$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "mysite";

$conn = new mysqli($serverName, $userName, $password, $databaseName);
if ($conn->connect_error) {
    echo "Database is not connected";
}
?>
<?php
$uid = $_SESSION['uid'];

if (isset($_POST['id']) && isset($_POST['quantity'])) {
    $id = $_POST['id'];
    $quantity = $_POST['quantity'];

    $sql = "select name, price, image from productdetails where id = $id";
    $result= $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = $row['name'];
        $price = $row['price'];
        $image = $row['image'];      

        $sqlcart = "insert into addtocart (uid, name, price, quantity, image) 
            values('$uid', '$name', '$price', '$quantity','$image')";

        if ($conn->query($sqlcart) === TRUE) {
            echo "<script>alert('Cart added successfully');document.location.href='cart.php';</script>";
        } else {
            echo "<script>alert('Cart not added successfully');document.location.href='menu.php';</script>";
        }
    } else {
        echo "Product not found";
    }
}
?>
<body>
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">CORNER CAFE</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="/Mysite/" class="nav-item nav-link">Home</a>
                    <a href="profile.php"  class="nav-item nav-link">Profile</a>
                    <a href="about.php" class="nav-item nav-link ">About</a>
                    <a href="menu.php" class="nav-item nav-link">Menu</a>
                    <a href="cart.php"  class="nav-item nav-link active">My Cart</a>
                    <a href="order.php"  class="nav-item nav-link">My Order</a>
                    <a href="setting.php" class="nav-item nav-link">Setting</a>
                    <a href="logout.php" class="nav-item nav-link">Sign out</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">MY CART</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">MY CART</p>
            </div>
        </div>
    </div>
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <h1 class="display-4">MY CART</h1>
            </div>
            <div class="row">
<?php
$uid = $_SESSION['uid'];
$sql_cart = "select * from addtocart where uid = $uid";
$resultcart = $conn->query($sql_cart);
$SubTotal = 0; 

if ($resultcart->num_rows > 0) {
?>
                <table>
                    <tr style='text-align:center;'>
                        <th>Product image</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Delete</th>
                    </tr>
<?php
    while ($row = $resultcart->fetch_assoc()) {
        $image = $row['image'];
        $imagePath = "../admin/" . $image;
        $total = $row['price'] * $row['quantity'];
        $SubTotal += $total;
?>
        <tr>
            <td><div class='center'><img src="<?php echo $imagePath; ?>"></div></td>
            <td><strong><?php echo $row['name']; ?></strong></td>
            <td style='text-align:center;'>RS <?php echo $row['price']; ?></td>
            <td style='text-align:center;'><?php echo $row['quantity']; ?></td>
            <td style='text-align:center;'>RS <?php echo $total; ?></td>
            <td><a class="remove-link" href="delete.php?cartid=<?php echo $row['cartid'];?>"><div class="div"><img class="size" src="delete1.png"></div></a></td>
        </tr>
<?php
    }
?>
        <tr>
            <td colspan='4' style='text-align:right;'><strong>Sub Total</strong></td>
            <td colspan='2'><strong>RS <?php echo $SubTotal; ?></strong></td>
        </tr>
<?php
    $GST = $SubTotal * 0.18;
    $SGST = $SubTotal * 0.09;
    $totalWithTax = $SubTotal + $GST + $SGST;
?>
        <tr>
            <td colspan='4' style='text-align:right;'><strong>GST 18%</strong></td>
            <td colspan='2'><strong>RS <?php echo $GST; ?></strong></td>
        </tr>
        <tr>
            <td colspan='4' style='text-align:right;'><strong>SGST 9%</strong></td>
            <td colspan='2'><strong>RS <?php echo $SGST; ?></strong></td>
        </tr>
        <tr>
            <td colspan='4' style='text-align:right;'><strong>Net Total (incl all tax)</strong></td>
            <td colspan='2'><strong>RS <?php echo $totalWithTax; ?></strong></td>
        </tr>
        <tr>
            <td colspan='4' style='text-align:right;'><strong>Everything you need-in a Bucket</strong></td>
            <td colspan='2'>
                <form method="POST" action="placeorder.php">
                    <button class="button" type="submit">PLACE ORDER</button>
                </form>
            </td>
        </tr>
    </table>
<?php
} else {
     echo "<script>alert('Your CORNER CAFE cart is empty ');document.location.href='menu.php';</script>";
}
?>
            </div>
        </div>
    </div>
<?php
    include "include/footerdata.html";
?>

</body>
</html>