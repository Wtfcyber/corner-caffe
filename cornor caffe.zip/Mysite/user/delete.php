<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    // echo "database is Connected";
}
if (isset($_GET['cartid'])) {
    $cartid = $_GET['cartid'];

    $sql = "delete from addtocart where cartid=$cartid";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Product deleted successfully');document.location.href='cart.php';</script>";
    } else {
        echo "<script>alert('Product deletion failed');document.location.href='menu.php';</script>";
    }
}

?>
