<!DOCTYPE html>
<?php 
    session_start();
    if(isset($_SESSION['uid'])==null){
        echo "<script>alert('Your session is expier');document.location.href='../signin.php';</script>";
    }
    else
    {
        $uid=$_SESSION["uid"];
    }
?>

<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>SETTING</title>
	<style type="text/css">
	form {
			background-color: #ffff;
            padding: 20px;
            border-radius:10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
            height: 450px;
            width: 400px;
            margin-left: 357px;
            margin-bottom: 150px;
    .txt{
            width: 90%;
            padding: 8px;   
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-left: 10px;
        }
        .button {
        	margin-left: 10px;
            width: 90%;
            padding: 10px;
            background-color: #6F4E37;
            border: none;
            border-radius: 3px;
            color: #fff;
            font-size: 16px;
            margin-top: 20px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .button:hover{
            background-color:#A67B5B;
            border-radius: 12px;
        }
        .sign-up{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 5px;
        }
        .p{
        	margin-bottom: 5px;
       		margin-top: 5px;
        	font-size: 17px;
        	margin-left: 12px;
        }
    </style>

</head>
<?php
    $serverName="localhost";
    $userName="root";
    $password="";
    $databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    //echo "database is Connected";
 }

    $sql="select * from userdata where uid='$uid'";
    $result=$conn->query($sql);
 while($row=$result->fetch_assoc()){
    $cpassword=$row["password"];
        }
        
?>
<?php  

	include "include/cssdata.html";
	// include "include/headerdata.html";
?>
<body>

<div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">CORNER CAFE</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="/Mysite/" class="nav-item nav-link">Home</a>
                    <a href="profile.php"  class="nav-item nav-link ">Profile</a>
                    <a href="about.php" class="nav-item nav-link">About</a>
                    <a href="menu.php" class="nav-item nav-link">Menu</a>
                     <a href="cart.php"  class="nav-item nav-link">My Cart</a>
                     <a href="order.php"  class="nav-item nav-link">My Order</a>
                    <a href="setting.php" class="nav-item nav-link active">Setting</a>
                    <a href="logout.php" class="nav-item nav-link">Sign out</a>
                    <!--<a href="signin.php" class="nav-item nav-link">Sign in</a>-->
                </div>
            </div>
        </nav>
    </div>
<div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Setting</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">Setting</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Contact Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <!-- <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Contact Us</h4> -->
                <h1 class="display-4"></h1>
            </div>
		<form class="signup-form" method="post" onsubmit="return validation()">
        <p class="p">Current Password</p>
        <input class="txt" type="password" name="currentpass">
        <p class="p">New Password</p>
        <input class="txt" type="password" name="newpassword">
		<br>
		<p class="p">Confirm Password</p>
        <input class="txt" type="password" name="confirmpassword">
		<br>
        <button class="button" type="submit" name="submit" value="Update">Update</button>
       
    </form>
    <?php

     if (isset($_POST["submit"])) {
        $currentPass = $_POST["currentpass"];
        $newPass = $_POST["newpassword"];
        $confirmPass = $_POST["confirmpassword"];

        if ($cpassword == $currentPass) {
            if ($newPass == $confirmPass) {

                $updateSql = "update userdata set password='$newPass' where uid='$uid'";
                if ($conn->query($updateSql) === TRUE) {
                    echo "<script>alert('Password Updated Successfully');document.location.href='setting.php';</script>";
                } else {
                    echo "<script>alert('Error Updating Password');document.location.href='setting.php';</script>";
                }
            } else {
                echo "<script>alert('New Password and Confirmpassword does not match');document.location.href='setting.php';</script>";
            }
        } else {
            echo "<script>alert('Current Password is incorrect');document.location.href='setting.php';</script>";
        }
    }

?>

					</div>
                </div>
            </div>
        </div>
    </div>
<?php
	include "include/footerdata.html";
?>
</body>
</html>