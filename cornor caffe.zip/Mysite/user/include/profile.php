<?php 
    session_start();
    if(isset($_SESSION['uid'])==null){
         // echo "<script>alert('Your session is expier');document.location.href='login.php';</script>";
    }
    else
    {
        $uid=$_SESSION["uid"];
    }
?>
<!-- <a href="user/profile.php" class="nav-item nav-link">Profile</a> -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
</head>
<body>
    <?php
    $serverName="localhost";
    $userName="root";
    $password="";
    $databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    //echo "database is Connected";
 }

    $sql="select * from userdata where uid='$uid'";
    $result=$conn->query($sql);
if ($result) {
 while($row=$result->fetch_assoc()){
    $name=$row["name"];
    $address=$row["address"];
    $phone=$row["phone"];
    $email=$row["email"];
        }
    }

?>
<style>  
        body{
            background-color:#A67B5B;
        }
       .body{
            font-family:Arial,sans-serif;
            background-color:#A67B5B;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .signup-form {
            background-color: #ffff;
            padding: 20px;
            border-radius:10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            height: 450px;
            width: 320px;
           
        }
        .signup-form h2 {
            margin-bottom: 20px;
            text-align: center;
            margin-top: 5px;
        }
        .signup-form input {
            width: 90%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .signup-form button {
            width: 95%;
            padding: 10px;
            background-color: black;
            border: none;
            border-radius: 3px;
            color: #fff;
            font-size: 16px;
            margin-top: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .signup-form button:hover {
            background-color:#252525;
            border-radius: 12px;
        }
        h5{
            margin: 5px;
        }
        .sign-up{
            display: flex;
            justify-content: center;
            align-items: center;
            text-decoration: none;
            margin-top: 5px;
        }
    </style>
</head>
<body>
<div class="body">
<form class="signup-form" method="POST" name="data">
        <h2>Profile</h2>

        <h5>Name</h5>
        <input type="text" value="<?php echo $name;?>" name="name">

        <h5>Address</h5>
        <input type="text" value="<?php echo $address;?>"name="address">

        <h5>Phone</h5>
        <input type="number"value="<?php echo $phone;?>" name="phone">

        <h5>Email</h5>
        <input type="text" value="<?php echo $email;?>"name="email">

        <button type="submit" name="submit" value="Update">Update </button>
    </form>
</div>
    
    <?php

        if(isset($_POST["submit"])!=null){
            $action=$_POST["submit"];
            if($action=="Update"){
                    $name=$_POST["name"];
                    $address=$_POST["address"];
                    $phone=$_POST["phone"];
                    $email=$_POST["email"];
$sql="update userdata set name='$name',address='$address',phone='$phone',email='$email'where uid='$uid'";

                    if($conn->query($sql)==true){
                        echo "<script>alert('user updated sucessfully');document.location.href='profile.php';</script>";
                    }
                    else
                    {
                    echo "<script>alert('user not updated sucessfully');document.location.href='profile.php';</script>";
                }
            }
        }
        
    ?>
</body>
</html>