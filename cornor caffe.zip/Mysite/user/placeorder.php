<?php
session_start();
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "mysite";

$conn = new mysqli($serverName, $userName, $password, $databaseName);
if ($conn->connect_error) {
    echo "Database is not connected";
    exit();
}
$uid = $_SESSION['uid'];
$sql_cart = "select name, price, quantity, image from addtocart where uid = $uid";
$resultcart = $conn->query($sql_cart);

if ($resultcart->num_rows > 0) {
    while ($row = $resultcart->fetch_assoc()) {
        $name = $row['name'];
        $price = $row['price'];
        $quantity = $row['quantity'];
        $image = $row['image'];
        $total = $price * $quantity;

$sql_order = "insert into userorder (uid, productname, price, quantity, total, image,orderdate) 
            values ('$uid', '$name', '$price', '$quantity', '$total', '$image', NOW())";

        if ($conn->query($sql_order) === TRUE) {
            echo "<script>alert('Order placed successfully'); document.location.href='order.php';</script>";
        } else {
            echo "<script>alert('Error placing order'); document.location.href='cart.php';</script>";
        }
    }
    $sql_deletecart = "delete from addtocart where uid = $uid";
    $conn->query($sql_deletecart);
}

$conn->close();
?>
