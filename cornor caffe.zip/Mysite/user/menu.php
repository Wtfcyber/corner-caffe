<!DOCTYPE html>
<html>
<head>
    <title>Menu & Pricing</title>
<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "mysite";

$conn = new mysqli($serverName, $userName, $password, $databaseName);
if ($conn->connect_error) {
    echo "Database is not Connected";
}
 else {
    // echo "Database is Connected";
}

$sql = "select * from productdetails";
$result = $conn->query($sql);

?>

<?php include "include/cssdata.html"; ?>

<style>
    .size {
        border-radius: 50%;
    }
    .button {
        text-align: center;
        border-radius: 5px;
        color: black;
        margin-top: 10px;
        border: none;
        height: 35px;
        width: 150px;
        background-color: #DA9F5B;
    }
    .button:hover {
        background-color: #DA9F5B;
        border-radius: 10px;
        color: black;
    }
    .btn{
        height: 35px;
        width: 35px;
    }
           .quantity-buttons {
        display: flex;
        margin-top: 18px;
        margin-left: 20px;
        align-items: center;
        border: none;
    }
    .quantity-buttons button {
        background-color: #DA9F5B;
        color: white;
        border: none;
        padding: 5px 10px;
        cursor: pointer;
    }
    .quantity-buttons input {
        height: 35px;
        width: 40px;
        text-align: center;
    }
</style>


</head>
<body>
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">CORNER CAFE</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="/Mysite/" class="nav-item nav-link">Home</a>
                    <a href="profile.php" class="nav-item nav-link">Profile</a>
                    <a href="about.php" class="nav-item nav-link">About</a>
                    <a href="menu.php" class="nav-item nav-link active">Menu</a>
                     <a href="cart.php"  class="nav-item nav-link">My Cart</a>
                     <a href="order.php"  class="nav-item nav-link">My Order</a>
                    <a href="setting.php" class="nav-item nav-link">Setting</a>
                    <a href="logout.php" class="nav-item nav-link">Sign out</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Menu</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">Menu</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->

    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Menu & Pricing</h4>
                <h1 class="display-4">Competitive Pricing</h1>
            </div>
            <div class="row">
                <?php 
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $image = $row['image'];
                        $imagePath = "../admin/" . $image;
                ?>  
                        <div class="col-lg-6">
                            <div class="row align-items-center mb-5">
                                <div class="col-4 col-sm-3">
                                    <img src="<?php echo $imagePath ?>" class="w-100 rounded-circle mb-3 mb-sm-0">
                                    <h5 class="menu-price"><?php echo $row['price']; ?></h5>
                                </div>
                                <div class="col-8 col-sm-9">
                                    <h4><?php echo $row['name']; ?></h4>
                                    <p class="m-0"><?php echo $row['description']; ?></p>
                                </div>
                            
                       
                                    <form method="post" action="cart.php">
                                        <div class="quantity-buttons">
                                            <button class="btn" type="button" onclick="this.nextElementSibling.stepDown()">-</button>
                                            <input type="number" name="quantity" value="1" min="1">
                                            <button class="btn" type="button" onclick="this.previousElementSibling.stepUp()">+</button>
                                        </div>


                                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                        <input type="submit" class="button" value="ADD TO CART">
                                    </form>
                                </div>
                            </div>
                      

                <?php
                    }
                } else {
                    echo "No products found";
                }
                ?>  
            </div>
        </div>
    </div>

<?php

 include "include/footerdata.html";
?>

</body>
</html>
