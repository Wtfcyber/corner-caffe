<!DOCTYPE html>
<?php 
 session_start();
  unset($_SESSION['uid']);
   echo"<script>alert('Sign out sucessfully');document.location.href='../signin.php';</script>";
 ?>

//<?php 
// session_start();
//  unset($_SESSION['adminId']);
//   echo"<script>alert('Sign out sucessfully');document.location.href='../admin.php';</script>";
// ?>