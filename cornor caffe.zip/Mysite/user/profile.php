<?php 
    session_start();
    if(isset($_SESSION['uid'])==null){
        echo "<script>alert('Your session is expier');document.location.href='../signin.php';</script>";
    }
    else
    {
        $uid=$_SESSION["uid"];
    }
?>
<!DOCTYPE html>
<html>  
<head>
</head>
<title>PROFILE</title>
<script type="text/javascript">
    function validation()
        {
            var name=document.data.name.value;
            if(name.length==0)
            {
                alert('Pls Enter Name');
                document.data.name.focus();
                return false;
            }
            if(name.length <2)
            {
                alert('Pls Enter valid Name');
                document.data.name.focus();
                return false;
            }

            var address=document.data.address.value;
            if(address.length==0){
                alert('Pls Enter address');
                address=document.data.address.value;
                return false;
            }
            var address=document.data.address.value;
            if(address.length==0){
                alert('Pls Enter address');
                address=document.data.address.value;
                return false;
            }
            if(address.length <5)
            {
                alert('Pls Enter valid  address');
                document.data.name.focus();
                return false;
            }

            var phone=document.data.phone.value;
            if(phone.length==0)
            {
                alert('Pls Enter Contact Number');
                document.data.phone.focus();
                return false;
            }
            var phoneexp = /^\d{10}$/;
            if(!phone.match(phoneexp))
            {
                alert('Pls Enter Valid Contact Number');
                document.data.phone.focus();
                return false;
            }

            var email=document.data.email.value;
            if(email.length==0)
            {
                alert('Pls Enter Email');
                document.data.email.focus();
                return false;
            }
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            if(!email.match(mailformat))
            {
                alert("Enter Valid email address!");
                document.data.email.focus();
                return false;
            } 
            return true;
        }
    </script>
    <?php
    $serverName="localhost";
    $userName="root";
    $password="";
    $databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    //echo "database is Connected";
 }

    $sql="select * from userdata where uid='$uid'";
    $result=$conn->query($sql);
// if ($result) {
 while($row=$result->fetch_assoc()){
    $name=$row["name"];
    $address=$row["address"];
    $phone=$row["phone"];
    $email=$row["email"];
    $image=$row["image"];
        }
 //   }
?>
<?php
    include "include/cssdata.html";
    // include "include/headerdata.html";
?>

<style>  
       .body{
            margin-top: 50px;
            margin-bottom: 200px;
            font-family:Arial,sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .signup-form {
            margin-top: 0px;
            background-color: #ffff;
            padding: 20px;
            border-radius:10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.7);
            height: 670px;
            width: 450px;
           
        }
        .h2 {
            margin-bottom: 20px;
            text-align: center;
            margin-top: 5px;
        }
        .txt{
            width: 95%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .button {
            width: 95%;
            padding: 10px;
            background-color: #6F4E37;
/*            background-color: black;*/
            border: none;
            border-radius: 3px;
            color: #fff;
            font-size: 16px;
            margin-top: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .button:hover {
            background-color:#A67B5B;
/*            background-color:#252525;*/
            border-radius: 12px;
        }
        .p{
            margin-bottom: 5px;
            margin-top: 5px;
            font-size: 17px;
            margin-left: 5px;
        }
        .sign-up{
            display: flex;
            justify-content: center;
            align-items: center;
            text-decoration: none;
            margin-top: 5px;
        }
        #uppercase{
            text-transform: uppercase; 
        }
        .image{
            height: 111px;
            display: flex;
            justify-content: center;
            align-content: center;
        }
        .aligntext{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
        }
        .align{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 5px;
            margin-left:50px;
        }
        .size{
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">CORNER CAFE</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="/Mysite/" class="nav-item nav-link">Home</a>
                    <a href="profile.php"  class="nav-item nav-link active">Profile</a>
                    <a href="about.php" class="nav-item nav-link ">About</a>
                    <a href="menu.php" class="nav-item nav-link">Menu</a>
                     <a href="cart.php"  class="nav-item nav-link">My Cart</a>
                     <a href="order.php"  class="nav-item nav-link">My Order</a>
                    <a href="setting.php" class="nav-item nav-link">Setting</a>
                    <a href="logout.php" class="nav-item nav-link">Sign out</a>
                    <!-- <a href="signin.php" class="nav-item nav-link">Sign in</a> -->
                </div>
            </div>
        </nav>
    </div>
    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Profile</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">Profile</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Contact Start -->
    <div class="container-fluid pt-5">
        <div class="container">
            <div class="section-title">
                <!-- <h4 class="text-primary text-uppercase" style="letter-spacing: 5px;">Contact Us</h4> -->
                <h1 class="display-4" id="uppercase"> WELCOME <?php echo $name;?> </h1>
            </div>
</div>
<div class="body">

<form class="signup-form" method="POST" name="data" enctype="multipart/form-data" onsubmit="return validation()"> 



        <div class="image">
        <?php 
         if (!isset($image) || $image == null) {
                $image ='img.avif';
        }
        ?>
            <img class="size" src="<?php echo $image; ?>"> 
        </div>

             <p class="aligntext">Change Profile</p>
        <div class="align">
            <input type="file" name="fileToUpload"/ name="image">  
        </div>

        <p class="p">Name</p>
        <input class="txt" type="text" value="<?php echo $name;?>" name="name">

        <p class="p">Address</p>
        <input class="txt" type="text" value="<?php echo $address;?>"name="address">

        <p class="p">Phone</p>
        <input class="txt" type="number"value="<?php echo $phone;?>" name="phone">

        <p class="p">Email</p>
        <input class="txt" type="text" value="<?php echo $email;?>"name="email">

        <button class="button" type="submit" name="submit" value="Update">Update </button>
    </form>
</div>  

     <?php

        if(isset($_POST["submit"])!=null){
                $action=$_POST["submit"];
                if($action=="Update"){
                    $name=$_POST["name"];
                    $address=$_POST["address"];
                    $phone=$_POST["phone"];
                    $email=$_POST["email"];
                    $imagePath = $image;

            if ($_FILES['fileToUpload']['name']){
                $target_path = "image/";
                $target_file = $target_path.basename($_FILES["fileToUpload"]["name"]);
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                $imagePath = $target_file;
             }
             else {
            echo "<script>alert('Image upload failed');</script>";
        }
    }
    $sql = "update userdata set name='$name', address='$address', phone='$phone', email='$email', image='$imagePath' where uid='$uid'";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('User updated successfully');document.location.href='profile.php';</script>";
    } else {
        echo "<script>alert('User update failed');</script>";
        }
    }

}
    
 
?> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
                <?php
                include "include/footerdata.html";
                ?>
</body>
</html>