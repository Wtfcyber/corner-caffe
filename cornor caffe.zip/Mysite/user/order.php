<?php
session_start();
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "mysite";

$conn = new mysqli($serverName, $userName, $password, $databaseName);
if ($conn->connect_error) {
    echo "Database is not connected";
}

$uid = $_SESSION['uid'];
$sql_orders = "select productname, price, quantity, total, image from userorder where uid = $uid";

$resultorders = $conn->query($sql_orders);
$SubTotal = 0;

if ($resultorders->num_rows > 0) {
    while ($row = $resultorders->fetch_assoc()) {
        $SubTotal += $row['total'];
    }
    $GST = $SubTotal * 0.18;
    $SGST = $SubTotal * 0.09;
    $totalWithTax = $SubTotal + $GST + $SGST;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MY ORDER</title>
    <style>
        .container {
            padding: 20px;
            margin: 20px auto;
            border-radius: 8px;
            max-width: 800px;
        }
        tr{
            text-align: center;
        }
        h1 {
            text-align: center;
            font-size: 24px;
            color: #333;
        }
        table {
            width: 90%;
            border-collapse: collapse;
            margin-top: 15px;
            margin-bottom: 30px;
        }
        table, th, td {
            border: 1px solid #f1f1f1;
        }
        th{
           padding: 15px;
           text-align: left;
        }
        td{
            padding: 15px;
           text-align: center;
        }
        th {
           background-color: #f2f2f2;
        }
        .total {
            text-align: left;
            font-weight: bold;
        }
        .totalx {
            text-align: right;
            font-weight: bold;
        }
        img {
            max-width: 100px;
            height: auto;
            border-radius: 50%;
        }

/*ORDER ACTIVITY*/

.row{
    display: flex;
    justify-content: center;
    align-content: center;
        }
.order-activity {
    display: flex;
    justify-content: space-between;
    margin: 20px 0;
}

.step {
    text-align: center;
    width: 30%;
    position: relative;
}

.step-number {
    font-size: 24px;
    width: 50px;
    height: 50px;
    line-height: 50px;
    margin: 0 auto;
    border-radius: 50%;
    background-color: #ddd;
    color: white;
}

.step-description {
    margin-top: 10px;
}

.completed .step-number {
    background-color: green;
}

.in-progress .step-number {
    background-color: orange;
}

.pending .step-number {
    background-color: gray;
}

.step:before {
    content: '';
    position: absolute;
    top: 25px;
    left: -50%;
    width: 100%;
    height: 2px;
    background-color: #ddd;
    z-index: -1;
}

.step:first-child:before {
    content: none;
}

.completed:before,
.in-progress:before {
    background-color: green;
}
    </style>
<?php
    include "include/cssdata.html";
?>
</head>
<body>
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <a href="index.html" class="navbar-brand px-lg-4 m-0">
                <h1 class="m-0 display-4 text-uppercase text-white">CORNER CAFE</h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="/Mysite/" class="nav-item nav-link">Home</a>
                    <a href="profile.php"  class="nav-item nav-link">Profile</a>
                    <a href="about.php" class="nav-item nav-link ">About</a>
                    <a href="menu.php" class="nav-item nav-link">Menu</a>
                    <a href="cart.php"  class="nav-item nav-link">My Cart</a>
                    <a href="order.php"  class="nav-item nav-link active">My Order</a>
                    <a href="setting.php" class="nav-item nav-link">Setting</a>
                    <a href="logout.php" class="nav-item nav-link">Sign out</a>
                </div>
            </div>
        </nav>
    </div>
    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">MY ORDER</h1>
            <div class="d-inline-flex mb-lg-5">
                <p class="m-0 text-white"><a class="text-white" href="">Home</a></p>
                <p class="m-0 text-white px-2">/</p>
                <p class="m-0 text-white">MY ORDER</p>
            </div>
        </div>
    </div>
    <div class="container-fluid pt-5">
<div class="container">
    <div class="section-title">
        <h1 class="display-4">ORDER SUMMARY</h1>
    </div>
    <div class="row">
    <?php if ($resultorders->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $resultorders->data_seek(0);
                while ($row = $resultorders->fetch_assoc()): ?>
                    <tr>
                        <td><img src="../admin/<?php echo $row['image']; ?>" alt="<?php echo $row['productname']; ?>"></td>
                        <td><?php echo $row['productname']; ?></td>
                        <td>RS <?php echo $row['price']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td>RS <?php echo $row['total']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4" class="totalx">Sub Total</td>
                    <td class="total">RS <?php echo $SubTotal; ?></td>
                </tr>
                <tr>
                    <td colspan="4" class="totalx">GST 18%</td>
                    <td class="total">RS <?php echo $GST; ?></td>
                </tr>
                <tr>
                    <td colspan="4" class="totalx">SGST 9%</td>
                    <td class="total">RS <?php echo $SGST; ?></td>
                </tr>
                <tr>
                    <td colspan="4" class="totalx">Net Total (incl all tax)</td>
                    <td class="total">RS <?php echo $totalWithTax; ?></td>
                </tr>
            </tfoot>
        </table>
<?php
    $sql="select * from userdata where uid='$uid'";
    $result=$conn->query($sql);
        while($row=$result->fetch_assoc()){
            $name=$row["name"];
    }
?>
        <p>Thank you for your purchase, <?php echo $name; ?>! &#128512;</p>
    <?php else: ?>       
        <p>No orders found.</p>
    <?php endif; ?>
        </div>
    </div>
</div>

    <div class="section-title">
        <h1 class="display-5">YOUR ORDER ACTIVITY</h1>
    </div>
            <div class="order-activity">
            <div class="step completed">
                <div class="step-number">1</div>
                <div class="step-description">Order was placed</div>
            </div>
            <div class="step in-progress">
                <div class="step-number">2</div>
                <div class="step-description">Package has dispatched</div>
            </div>
            <div class="step pending">
                <div class="step-number">3</div>
                <div class="step-description">Delivered</div>
            </div>
            </div>

<?php
    include "include/footerdata.html";
?>
</body>
</html>