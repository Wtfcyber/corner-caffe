<html>
<head>
	<title>Sign Up</title>
    <script type="text/javascript">
    function validation()
        {
            var name=document.data.name.value;
            if(name.length==0)
            {
                alert('Pls Enter Name');
                document.data.name.focus();
                return false;
            }
            if(name.length <2)
            {
                alert('Pls Enter valid Name');
                document.data.name.focus();
                return false;
            }

            var address=document.data.address.value;
            if(address.length==0){
                alert('Pls Enter address');
                address=document.data.address.value;
                return false;
            }
            var address=document.data.address.value;
            if(address.length==0){
                alert('Pls Enter address');
                address=document.data.address.value;
                return false;
            }
            if(address.length <5)
            {
                alert('Pls Enter valid  address');
                document.data.name.focus();
                return false;
            }

            var phone=document.data.phone.value;
            if(phone.length==0)
            {
                alert('Pls Enter Contact Number');
                document.data.phone.focus();
                return false;
            }
            var phoneexp = /^\d{10}$/;
            if(!phone.match(phoneexp))
            {
                alert('Pls Enter Valid Contact Number');
                document.data.phone.focus();
                return false;
            }

            var email=document.data.email.value;
            if(email.length==0)
            {
                alert('Pls Enter Email');
                document.data.email.focus();
                return false;
            }
            var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
            if(!email.match(mailformat))
            {
                alert("Enter Valid email address!");
                document.data.email.focus();
                return false;
            } 

            var password=document.data.password.value;
            if(password.length==0)
            {
                alert('Pls Enter Password');
                document.data.password.focus();
                return false;
            }
            if(password.length <8 || password.length>20)
            {
                alert('Password min length is 8 and max is 20');
                document.data.password.focus();
                return false;
            }
            var lowerCaseLetters = /[a-z]/g;
            if(!password.match(lowerCaseLetters))
            {
                alert('Password Contain Atleast one Lower Case');
                document.data.password.focus();
                return false;
            }
            var upperCaseLetters = /[A-Z]/g;
            if(!password.match(upperCaseLetters))
            {
                alert('Password Contain Atleast one Upper Case');
                document.data.password.focus();
                return false;
            }
            var number = /[0-9]/g;
            if(!password.match(number))
            {
                alert('Password Contain Atleast one Digit');
                document.data.password.focus();
                return false;
            }
            var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
            if(!password.match(format))
            {
                alert('Password Contain Atleast one Special Character');
                document.data.password.focus();
                return false;
            }
            
            return true;
        }
    </script>
	<?php
	$serverName="localhost";
	$userName="root";
	$password="";
	$databaseName="mysite";

$conn=new mysqli($serverName,$userName,$password,$databaseName);
if($conn->connect_error){
    echo "database is not Connected";
}
else
{
    //echo "database is Connected";
}
	?>
	<style>
        body{
            font-family:Arial,sans-serif;
            background-color:#A67B5B;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;

        }
        .signup-form {
            background-color: #ffff;
            padding: 20px;
            border-radius:10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            height: 470px;
            width: 250px;
        }
        .h2{
            margin-bottom: 20px;
            text-align: center;
            margin-top: 5px;
        }
        .txt {
            width: 90%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .button {

            width: 100%;
            padding: 10px;
            background-color: black;
            border: none;
            border-radius: 3px;
            color: #fff;
            font-size: 16px;
            margin-top: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .button:hover {
            background-color:#252525;
            border-radius: 12px;
        }
        h5{
            margin: 5px;
        }
        .sign-up{
            display: flex;
            justify-content: center;
            align-items: center;
            text-decoration: none;
            margin-top: 5px;
        }
        
    </style>
</head>
<body>
<form class="signup-form" method="POST" name="data"onsubmit="return validation()">
        <h2 class="h2">Sign Up</h2>

        <h5>Name</h5>
        <input class="txt" type="text" name="name">

        <h5>Address</h5>
        <input class="txt" type="text" name="address">

        <h5>Phone</h5>
        <input class="txt" type="number" name="phone">

        <h5>Email</h5>
        <input class="txt" type="text" name="email">

        <h5>Password</h5>
        <input class="txt" type="password" name="password">

        <button class="button" type="submit" name="submit" value="Save">Sign Up</button>

        <a href="login.php"class="sign-up">Sign In</a>
    </form>
    <?php
        if(isset($_POST["submit"])!=null)
        {
            $action=$_POST["submit"];
            if ($action=="Save"){
                $name=$_POST["name"];
                $address=$_POST["address"];
                $phone=$_POST["phone"];
                $email=$_POST["email"];
                $pass=$_POST["password"];
                $sql="insert into userdata(name,address,phone,email,password)values('$name','$address',
            '$phone','$email','$pass')";
                                    
            if($conn->query($sql)==true){
                        echo "<script>alert('User addded sucessfully');document.location.href='login.php';</script>";
                        }
            else
                    {
                    echo "<script>alert('User not addded sucessfully');document.location.href='sign.php';</script>";
                }
            }
        } 
    ?>
</body>
</html>